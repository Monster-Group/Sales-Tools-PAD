define(['angular', 'require','js.cookie','moment', 'angular-route','appDirectives','appServices','appFactorys','appTemplates','jquery','Ps','daterange','waves','sweetalert','bootstrap','nprogress','tap'], function(){
	
});